# Pest 2 Veg — Updated assignment package

All included materials have been rebranded from Pest Tech to **Pest 2 Veg**.

- `Pest_2_Veg_Group_Submission/`: website, presentation, group report, academic draft, portfolio templates and viva checklist.
- `Ike_Individual_Work/`: Ike’s academic article and four reflection drafts.
- `Penpot_6_Desktop_SVG/`: six editable SVG desktop designs with embedded photorealistic illustrative images and JPG assets.

**Before submitting:** verify factual claims, references, actual contribution records, test results, GitHub link, and any required AI declaration. The pest imagery is illustrative, not authenticated identification photography.
