# Pest 2 Veg — Penpot screen kit

Six 1440 × 900 editable SVG screens are provided. In Penpot, create a project, then drag each SVG into the canvas or use the import file option. SVG text and vector elements can be edited; regroup elements as needed. Arrange screens in order: Home → Pest Library → Pest Details; Home → Symptom Guide → Results → Pest Details; Home → Guidance. Use Penpot Prototype interactions to connect buttons and navigation. These SVGs are visual mockups, not a working Penpot prototype or validated pest imagery. Create a mobile variant (390 × 844) using vertical cards and a condensed menu.

**Suggested interactions:** Home Browse → Library; Home Identify → Symptom Guide; Library card → Details; Symptom Guide Next → Results; Results View details → Details; all pages header Guidance → Guidance.

**Design tokens:** primary #1F7951, dark #174D37, background #F5F9F4, surface #FFFFFF, muted #64756B; rounded corners 16–28 px.
