# Pest 2 Veg — Pest Detection Information Web App

Student educational prototype for CPU4106-20C, SDG 2. Open `index.html` in a modern browser. No server or dependencies required. Search and area filters and a symptom-to-possible-pest guide are implemented. The prototype uses text/illustration rather than pest photographs; adding appropriately licensed verified photographs is future work. This is NOT image-recognition AI or a confirmed diagnosis.

## Manual verification
1. Search `aphids` → Aphids shown.
2. Search `sticky` → multiple relevant entries.
3. Choose `Stems` → Cutworms and Mealybugs.
4. Choose `Fine webbing` → Spider mites.
5. Choose no symptom → helpful validation message.
6. Test keyboard navigation and mobile widths.

Evidence such as Git commits, screenshots and actual test logs must be gathered by the group.
