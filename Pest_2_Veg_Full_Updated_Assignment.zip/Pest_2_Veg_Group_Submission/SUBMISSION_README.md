# Pest 2 Veg — CPU4106-20C submission pack

This is an editable prototype and evidence-preparation pack, **not** a verified record of completed team activity.

## Files
- `webapp/index.html`: open in a browser to run the static application.
- `Group_Project_Report.docx`: project design and management draft; complete evidence register.
- `Individual_Article_Draft.docx`: research article draft; personally revise, check 1,350–1,650-word main-body limit and IEEE citations.
- `Weekly_Portfolio_Templates.docx`: complete with each individual's actual activity and evidence (180–220 words per week).
- `Presentation_With_Speaker_Notes.pptx`: 18 slides for a 15-minute live presentation; rehearse and add authentic screenshots.
- `Viva_Questions_and_Checklist.md`: viva preparation.

## Submission
1. Verify agricultural content with authoritative sources and obtain licences for any photographs you add.
2. Record real stand-ups, sprint outcomes, GitHub commits and actual test results.
3. Upload webapp source to GitHub and test the repository version.
4. Submit slides and individually authored academic articles to Moodle according to the brief.
5. Submit weekly portfolios by the designated Mondays.
6. Include a truthful statement of authenticity and disclose AI assistance as required.

No user testing, live deployment, agricultural field validation or completed teamwork evidence is claimed in this pack.
