# Viva preparation

1. Why SDG 2? The tool improves access to pest information, without claiming measured impact.
2. Why HTML/CSS/JS? Small static prototype, simple deployment and separation of concerns.
3. Is it AI pest detection? No; it is a rule-based educational information guide.
4. What happens when symptoms overlap? Multiple possible matches are shown; expert confirmation is recommended.
5. How is the data stored? Locally in a JavaScript array; no backend or personal data collection.
6. What did each member contribute? Show real commits and explain implementation decisions.
7. What Scrum evidence exists? Present actual backlog, stand-ups and sprint reviews.
8. How did you test? Demonstrate each case and provide dated test records.
9. What is the biggest limitation? No expert-validated diagnosis or real-world outcome evidence.
10. What next? Expert review, accessible licensed photos, usability study, crop-specific information.

## Before submission
- [ ] Verify academic references and add citations throughout the article.
- [ ] Each student writes their own 1,350–1,650-word article and four 180–220-word reflections.
- [ ] Add real stand-up attendance, GitHub history, screenshots and testing outcomes.
- [ ] Replace any proposed schedule with actual dates.
- [ ] Upload code to GitHub and test its published URL.
- [ ] Rehearse 15-minute live talk and 5-minute Q&A.
- [ ] Add authenticity/AI use statement consistent with university guidance.
