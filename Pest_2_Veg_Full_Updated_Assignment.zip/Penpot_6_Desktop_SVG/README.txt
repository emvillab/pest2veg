Pest 2 Veg — six desktop SVG designs, 1440 × 900 each.

Photo-style crop and pest images are embedded inside the SVG files; editable text, buttons, cards and layout shapes remain vector elements in Penpot. Image content is raster, not individually editable as vector paths. The pictures are cropped from an AI-generated photorealistic design reference and are NOT verified photographs of real pests. Do not use them for scientific identification without replacing them with verified, licensed photographs.

Drag each SVG into Penpot. All images are self-contained; the Photo_Assets folder provides reusable JPG crops.
